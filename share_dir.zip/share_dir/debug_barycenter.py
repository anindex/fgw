import torch
from src.model.fgw.barycenter import fgw_barycenters
debug_dict = torch.load("/home/taindp/workspace/2d_3d_molecular/share_dir/debug_barycenter.pt")
F_bary, C_bary = fgw_barycenters( N=debug_dict["N"], Ys=debug_dict["Ys"], Cs=debug_dict["Cs"], ps=debug_dict["ps"], lambdas=debug_dict["lambdas"], alpha=0.5, fixed_structure=True, fixed_features=False, epsilon=0.1, p=None, loss_fun='square_loss', max_iter=30, tol=1e-2, rank=None, bapg=False, rho=0.1, numItermax=100, verbose=False, log=False, init_C=debug_dict["Cs"][0], init_X=None, random_state=None)